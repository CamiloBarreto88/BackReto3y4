/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reto3.Reto3;

import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author DELL
 */
public interface InterfaceGama extends CrudRepository<Gama, Integer>{
    
}
